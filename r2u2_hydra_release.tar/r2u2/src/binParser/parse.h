#include "TL_observers.h"

void parse_inst_ft(char*);
void parse_inst_pt(char*);

void parse_interval_ft(char*);
void parse_interval_pt(char*);

void parse_scq_size(char*);
